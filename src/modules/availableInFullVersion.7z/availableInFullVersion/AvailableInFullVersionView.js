import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,ToastAndroid,
  ImageBackground,
  Linking,
} from 'react-native';

import { fonts, colors } from '../../styles';
import { Button } from '../../components';

export default function AvailableInFullVersionScreen(props) {


 const showToastWithGravity = () => {
    ToastAndroid.showWithGravity(
      "Future Use Cases",
      ToastAndroid.SHORT,
      ToastAndroid.CENTER
    );
  };
  return (
    <ImageBackground
      style={styles.container}
    >
      <Image
        source={require('../../../assets/images/logo.png')}
        style={styles.blazorlogo}
      />

      <View style={styles.textContainer}>
        <Text style={styles.availableText}>Blazor</Text>
        <Text style={styles.availableText}>Technologies Inc.</Text>
        <Text style={styles.contactText}>www.blazortech.com</Text>
      </View>

      <View style={styles.buttonsContainer}>
        <Button
          large
          secondary
          rounded
          style={styles.button}
          caption="Contact"  
	  onPress={() => showToastWithGravity()} 
        />

        <Button
          large
          bordered
          rounded
          style={styles.button}
          caption="Later"
          onPress={() => props.navigation.goBack()}
        />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.BlazorBg,
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 30,
    paddingVertical: 50,
    justifyContent: 'space-around',
  },
 blazorlogo: {
    width: 80,
    height: 80,
  },
  availableText: {
    color: colors.white,
    fontFamily: fonts.primaryRegular,
    fontSize: 40,
    marginVertical: 3,
  },
contactText: {
    color: colors.maroon,
    fontFamily: fonts.primaryRegular,
    fontSize: 24,
    marginVertical: 3,
  },
  textContainer: {
    alignItems: 'center',
  },
  buttonsContainer: {
    alignItems: 'center',
    alignSelf: 'stretch',
  },
  button: {
    alignSelf: 'stretch',
    marginBottom: 20,
  },
});
